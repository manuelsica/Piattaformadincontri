
import javax.swing.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		//si crea il frame e poi si settano eventuali dimensioni
				
		
		JFrame frame= new PrimaryFrame();
		frame.setTitle("PIATTAFORMA DI INCONTRI");
		frame.setLocation(550,300);
		frame.setSize(400,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		frame.setVisible(true);
		
		ImageIcon image= new ImageIcon("sito.png");		
		frame.setIconImage(image.getImage());
		
		
	}

}
