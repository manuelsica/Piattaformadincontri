

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Locale;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.xml.crypto.Data;

public class SignIn extends JFrame {
	private JButton one;
	private JButton two;
	private JButton three;
	private JButton four;
	private JButton five;
	private JButton six;
	private JButton seven;
	private JButton eight;
	private JButton nine;
	private JButton ten;
	private JButton eleven;
	private JButton twelve;
	private JButton thirteen;
	private JButton fourteen;
	private JButton fifteen;
	private JButton sixteen;
	private JButton seventeen;
	private JButton eighteen;
	private JButton nineteen;
	private JButton twenty;
	private ActionListener button1;
	private ActionListener button2;
	private ActionListener button3;
	private ActionListener button4;
	private ActionListener button5;
	private ActionListener button6;
	private ActionListener button7;
	private ActionListener button8;
	private ActionListener button9;
	private ActionListener button10;
	private ActionListener button11;
	private ActionListener button12;
	private ActionListener button13;
	private ActionListener button14;
	private ActionListener button15;
	private ActionListener button16;
	private ActionListener button17;
	private ActionListener button18;
	private ActionListener button19;
	private ActionListener button20;
	private JFrame input;
	private JTextArea area;
	private JTextField a;
	private JLabel txt;
	private JPanel panel;
	private ActionListener lst;
	private int tel;
	private JFrame id;
	private JFrame pas;
	private JTextField a1;
	private JTextField a2;
	private JTextField a3;
	private JTextField a4;
	private JTextField a5;
	private JTextField a6;
	private JTextField a7;
	private JLabel txt1;
	private JLabel txt2;
	private JLabel txt3;
	private JLabel txt4;
	private JLabel txt5;
	private JLabel txt6;
	private JLabel txt7;
	private JFrame tab;
	private JFrame cdl;
	private JFrame dat;
	
	
	public SignIn() {
	JPanel dx= new JPanel();
	JPanel sx = new JPanel();
	area= new JTextArea();

	
		class Button1 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				id= new Id();
				id.setSize(600,200);
				id.setTitle("Selezionare gli utenti di un dato match e data");
				id.setLocation(400,100);
				id.setVisible(true);
				
				ImageIcon image= new ImageIcon("sito.png");		
				id.setIconImage(image.getImage());
				
			}
		}
		
		class Button2 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Leggere ID di un Match");
				input.setLocation(400,100);
				input.setVisible(true);
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button3 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				tab= new Table();
				tab.setSize(400,350);
				tab.setTitle("Creazione di un nuovo profilo");
				tab.setLocation(400,100);
				tab.setVisible(true);
				
				ImageIcon image= new ImageIcon("sito.png");		
				tab.setIconImage(image.getImage());
			}
		}

		class Button4 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Nuovo match grazie alla stesura di una bio di un dato profilo");
				input.setLocation(400,100);
				input.setVisible(true);
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button5 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Motivo di iscrizione di un utente alla piattaforma");
				input.setLocation(400,100);
				input.setVisible(true);
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button6 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Visualizzara data sottoscrizione di un utente premium");
				input.setLocation(400,100);
				input.setVisible(true);
	
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button7 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Rate d'intrresse e numero di posto in classifica di un profilo");
				input.setLocation(400,100);
				input.setVisible(true);
				
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button8 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				cdl= new Cdl();
				cdl.setSize(400,200);
				cdl.setTitle("Nuovo orientamento che influisce un nuovo match");
				cdl.setLocation(400,100);
				cdl.setVisible(true);
				
				
				ImageIcon image= new ImageIcon("sito.png");		
				cdl.setIconImage(image.getImage());
			}
		}

		class Button9 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Numero massimo di match di un utente");
				input.setLocation(400,100);
				input.setVisible(true);
				
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button10 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				pas= new Pas();
				pas.setSize(400,400);
				pas.setTitle("Modifica password di un profilo");
				pas.setLocation(400,100);
				pas.setVisible(true);
				
				
				ImageIcon image= new ImageIcon("sito.png");		
				pas.setIconImage(image.getImage());
				
			}
		}

		class Button11 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				dat= new Dat();
				dat.setSize(400,200);
				dat.setTitle("Nuovo like lasciato da un profilo con una mail che inizia con L");
				dat.setLocation(400,100);
				dat.setVisible(true);
				
				
				ImageIcon image= new ImageIcon("sito.png");		
				dat.setIconImage(image.getImage());
			}
		}

		class Button12 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryDodici(area);
			}
		}

		class Button13 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryTredici(area);
			}
		}

		class Button14 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryQuattordici(area);
			}
		}

		class Button15 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryQuindici(area);
			}
		}

		class Button16 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				querySedici(area);
			}
		}

		class Button17 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryDiciassette(area);
			}
		}

		class Button18 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryDiciotto(area);
			}
		}

		class Button19 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				input= new InputTelefono();
				input.setSize(400,200);
				input.setTitle("Lista dei like di un utente premium");
				input.setLocation(400,100);
				input.setVisible(true);
				
				ImageIcon image= new ImageIcon("sito.png");		
				input.setIconImage(image.getImage());
			}
		}

		class Button20 implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				queryVenti(area);
			}
		}
	
		
	button1= new Button1();
	button2= new Button2();
	button3= new Button3();
	button4= new Button4();
	button5= new Button5();
	button6= new Button6();
	button7= new Button7();
	button8= new Button8();
	button9= new Button9();
	button10= new Button10();
	button11= new Button11();
	button12= new Button12();
	button13= new Button13();
	button14= new Button14();
	button15= new Button15();
	button16= new Button16();
	button17= new Button17();
	button18= new Button18();
	button19= new Button19();
	button20= new Button20();
	
	one= new JButton("Operazione 1");
	one.addActionListener(button1);
	two= new JButton("Operazione 2");
	two.addActionListener(button2);
	three= new JButton("Operazione 3");
	three.addActionListener(button3);
	four= new JButton("Operazione 4");
	four.addActionListener(button4);
	five= new JButton("Operazione 5");
	five.addActionListener(button5);
	six= new JButton("Operazione 6");
	six.addActionListener(button6);
	seven= new JButton("Operazione 7");
	seven.addActionListener(button7);
	eight= new JButton("Operazione 8");
	eight.addActionListener(button8);
	nine= new JButton("Operazione 9");
	nine.addActionListener(button9);
	ten= new JButton("Operazione 10");
	ten.addActionListener(button10);
	eleven= new JButton("Operazione 11");
	eleven.addActionListener(button11);
	twelve= new JButton("Operazione 12");
	twelve.addActionListener(button12);
	thirteen= new JButton("Operazione 13");
	thirteen.addActionListener(button13);
	fourteen= new JButton("Operazione 14");
	fourteen.addActionListener(button14);
	fifteen= new JButton("Operazione 15");
	fifteen.addActionListener(button15);
	sixteen= new JButton("Operazione 16");
	sixteen.addActionListener(button16);
	seventeen= new JButton("Operazione 17");
	seventeen.addActionListener(button17);
	eighteen= new JButton("Operazione 18");
	eighteen.addActionListener(button18);
	nineteen= new JButton("Operazione 19");
	nineteen.addActionListener(button19);
	twenty= new JButton("Operazione 20");
	twenty.addActionListener(button20);
	
	sx.add(one);
	sx.add(two);
	sx.add(three);
	sx.add(four);
	sx.add(five);
	sx.add(six);
	sx.add(seven);
	sx.add(eight);
	sx.add(nine);
	sx.add(ten);
	
	dx.add(eleven);
	dx.add(twelve);
	dx.add(thirteen);
	dx.add(fourteen);
	dx.add(fifteen);
	dx.add(sixteen);
	dx.add(seventeen);
	dx.add(eighteen);
	dx.add(nineteen);
	dx.add(twenty);
	
	setLayout(new BorderLayout());	
	sx.setLayout(new GridLayout(10,1));
	dx.setLayout(new GridLayout(10,1));
	add(dx, BorderLayout.EAST);
	add(sx, BorderLayout.WEST);
	add(area, BorderLayout.CENTER);
	
	

	}
	
	public class InputTelefono extends JFrame {
		
		public InputTelefono() {
			a = new JTextField(20);
			txt = new JLabel("Telefono: ");
			txt.getText();
			
			class Lst implements ActionListener{
				@Override
				public void actionPerformed(ActionEvent e) {
					tel=Integer.parseInt(a.getText());
					queryDue(tel, area);
					setVisible(false);
				}
			}
			lst= new Lst();
			
			JButton but= new JButton("Avanti");
			but.addActionListener(lst);
			
			
			panel= new JPanel();
			panel.add(txt);
			panel.add(a);
			panel.add(but);
			
			add(panel);
			
		}
	}
	
	public class Id extends JFrame {
		
		public Id() {
			a = new JTextField(10);
			txt = new JLabel("ID Match: ");
			
			class Lst implements ActionListener{
				@Override
				public void actionPerformed(ActionEvent e) {
					int id=Integer.parseInt(a.getText());
					queryUno(id, area);
					setVisible(false);
				}
			}
			lst= new Lst();
			
			JButton but= new JButton("Avanti");
			but.addActionListener(lst);
			
			
			panel= new JPanel();
			panel.add(txt);
			panel.add(a);
			panel.add(but);
			

			add(panel);

			
		}
	}
	
	public class Table extends JFrame{
		
		public Table() {
			a1 = new JTextField(10);
			a2 = new JTextField(10);
			a3 = new JTextField(10);
			a4 = new JTextField(10);
			a5 = new JTextField(10);
			a6 = new JTextField(10);
			a7 = new JTextField(10);
			
			txt1 = new JLabel("Telefono: ");
			txt2 = new JLabel("E-Mail: ");
			txt3 = new JLabel("Nome: ");
			txt4 = new JLabel("Cognome: ");
			txt5 = new JLabel("Genere: ");
			txt6 = new JLabel("Data: ");
			txt7 = new JLabel("Password: ");
			
			
			class Lst implements ActionListener{
				@Override
				public void actionPerformed(ActionEvent e) {
					tel=Integer.parseInt(a1.getText());
					String mail= a2.getText();
					String nome=a3.getText();
					String cognome= a4.getText();
					String genere= a5.getText();
					String d = a6.getText();
					String pass= a7.getText();
					DateFormat df = new SimpleDateFormat("YYYY-MM-DD"); 
					java.util.Date data = df.parse(d);
					queryTre(tel, mail, nome, cognome, genere, data, pass, area);
					setVisible(false);
				}
			}
			lst= new Lst();		
			
			
			JButton but= new JButton("Avanti");
			but.addActionListener(lst);
			
			
			panel= new JPanel();
			panel.setLayout(new BorderLayout());
			JPanel text= new JPanel();
			JPanel ss= new JPanel();
			text.setLayout(new GridLayout(8,1));
			ss.setLayout(new GridLayout(8,1));
			
			
			text.add(txt1);
			ss.add(a1);
			text.add(txt2);
			ss.add(a2);
			text.add(txt3);
			ss.add(a3);
			text.add(txt4);
			ss.add(a4);			
			text.add(txt5);
			ss.add(a5);			
			text.add(txt6);
			ss.add(a6);
			text.add(txt7);
			ss.add(a7);
			ss.add(but);
			
			panel.add(text, BorderLayout.WEST);
			panel.add(ss, BorderLayout.CENTER);
			
			JPanel pan= new JPanel();
			pan.add(panel);
			
			add(pan);
			
		}
	}
	
	public class Cdl extends JFrame{
		
		public Cdl() {
			
			a1 = new JTextField(10);
			a2 = new JTextField(10);
			a3 = new JTextField(10);
			a4 = new JTextField(10);
			
			txt1 = new JLabel("ID Match: ");
			txt2 = new JLabel("Orientamento: ");
			txt3 = new JLabel("Bio: ");
			txt4 = new JLabel("Data: ");			
			
			
			class Lst implements ActionListener{
				@Override
				public void actionPerformed(ActionEvent e) {
					int id=Integer.parseInt(a1.getText());
					String or=a2.getText();
					String bio= a3.getText();
					String d= a4.getText();
					DateFormat df = new SimpleDateFormat("YYYY-MM-DD"); 
					java.util.Date data = df.parse(d);
					queryOtto(id, or, bio, data, area);
					setVisible(false);
				}
			}
			lst= new Lst();
			
			JButton but= new JButton("Avanti");
			but.addActionListener(lst);
			
			
			panel= new JPanel();
			panel.setLayout(new BorderLayout());
			
			JPanel p= new JPanel();
			JPanel t= new JPanel();
			
			p.setLayout(new GridLayout(5,1));
			t.setLayout(new GridLayout(5,1));
			p.add(txt1);
			t.add(a1);
			p.add(txt2);
			t.add(a2);
			p.add(txt3);
			t.add(a3);
			p.add(txt4);			
			t.add(a4);
			t.add(but);
			
			panel.add(p, BorderLayout.WEST);
			panel.add(t, BorderLayout.CENTER);
			JPanel pan= new JPanel();
			pan.add(panel);
			
			
			add(pan);
			
			
			
		}
	}
	public class Pas extends JFrame{
		public Pas() {
			a1 = new JTextField(10);
			a2 = new JTextField(10);
			txt1 = new JLabel("Password: ");
			txt2 = new JLabel("Telefono: ");
			
			class Lst implements ActionListener{
				@Override
				public void actionPerformed(ActionEvent e) {
					int pass=Integer.parseInt(a.getText());
					tel=Integer.parseInt(a.getText());
					queryDieci(pass, tel, area);
					setVisible(false);
				}
			}
			lst= new Lst();
			
			JButton but= new JButton("Avanti");
			but.addActionListener(lst);
			
			
			panel= new JPanel();
			panel.setLayout(new BorderLayout());
			
			JPanel p= new JPanel();
			JPanel t= new JPanel();
			
			p.setLayout(new GridLayout(3,1));
			t.setLayout(new GridLayout(3,1));
			p.add(txt1);
			t.add(a1);
			p.add(txt2);
			t.add(a2);
			t.add(but);
			
			panel.add(p, BorderLayout.WEST);
			panel.add(t, BorderLayout.CENTER);	
			
			JPanel pan= new JPanel();
			pan.add(panel);
			
			add(pan);
			
		}
		
	}
	
	public class Dat extends JFrame{
		public Dat() {
			a1 = new JTextField(10);
			a2 = new JTextField(10);
			txt1 = new JLabel("Data: ");
			txt2 = new JLabel("Ora: ");
			
			class Lst implements ActionListener{
				@Override
				public void actionPerformed(ActionEvent e) {
					String d =a1.getText();
					DateFormat df = new SimpleDateFormat("YYYY-MM-DD"); 
					java.util.Date data = df.parse(d);
					String o =a2.getText();
					LocalTime ora= LocalTime.parse(o);
					queryUndici(data, ora, area);
					setVisible(false);
				}
			}
			lst= new Lst();
			
			JButton but= new JButton("Avanti");
			but.addActionListener(lst);
			
			
			panel= new JPanel();
			panel.setLayout(new BorderLayout());
			
			JPanel p= new JPanel();
			JPanel t= new JPanel();
			
			p.setLayout(new GridLayout(3,1));
			t.setLayout(new GridLayout(3,1));
			p.add(txt1);
			t.add(a1);
			p.add(txt2);
			t.add(a2);
			t.add(but);
			
			panel.add(p, BorderLayout.WEST);
			panel.add(t, BorderLayout.CENTER);	
			
			JPanel pan= new JPanel();
			pan.add(panel);
			
			add(pan);
		}
	}

}
